const fs = require('fs');
const path = require('path');

module.exports = (client) => {
  const dir = path.join(__dirname, '..', 'events');
  const eventFiles = fs.readdirSync(dir).filter((file) => file.endsWith('.js'));
  for (const file of eventFiles) {
    const event = require(path.join(dir, file));
    if (event.once) {
      client.once(event.name, (...args) => event.execute(...args, client));
    } else {
      client.on(event.name, (...args) => event.execute(...args, client));
    }
  }
};
